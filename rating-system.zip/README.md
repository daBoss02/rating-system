## React Rating System

Uses React Icons

Click [here](https://daboss02.github.io/rating-system/) to view a live demo.